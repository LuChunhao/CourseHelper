package com.zhuangfei.timetable.listener;

/**
 * WeekView的Item点击监听默认实现
 */

public class OnWeekItemClickedAdapter implements IWeekView.OnWeekItemClickedListener {
    @Override
    public void onWeekClicked(int curWeek) {

    }
}
