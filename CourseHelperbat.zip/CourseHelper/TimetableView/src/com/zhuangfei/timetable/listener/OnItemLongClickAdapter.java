package com.zhuangfei.timetable.listener;

import android.view.View;

import com.zhuangfei.timetable.model.Schedule;

import java.util.List;

/**
 * Created by Liu ZhuangFei on 2018/8/3.
 */

public class OnItemLongClickAdapter implements ISchedule.OnItemLongClickListener {
    @Override
    public void onLongClick(View v, List<Schedule> scheduleList, int day, int start, Schedule subject) {

    }
}
