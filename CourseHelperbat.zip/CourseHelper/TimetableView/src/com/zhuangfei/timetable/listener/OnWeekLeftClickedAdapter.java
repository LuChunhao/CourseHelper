package com.zhuangfei.timetable.listener;

/**
 * WeekView的左侧按钮点击监听默认实现
 */

public class OnWeekLeftClickedAdapter implements IWeekView.OnWeekLeftClickedListener {
    @Override
    public void onWeekLeftClicked() {

    }
}
